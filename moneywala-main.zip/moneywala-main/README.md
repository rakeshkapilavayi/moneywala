# moneywala

Download zip file and extract it to get the desired code
